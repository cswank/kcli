#define USE_FAKE_ADDRINFO
#include "addrinfo-test.c"
