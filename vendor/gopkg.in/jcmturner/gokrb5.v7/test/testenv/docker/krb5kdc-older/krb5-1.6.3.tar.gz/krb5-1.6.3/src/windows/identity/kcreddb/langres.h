//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by D:\work\pismere\athena\auth\krb5\src\windows\identity\kcreddb\lang\en_us\kcredres.rc
//
#define IDS_CREDDB                      101
#define IDS_NAME                        102
#define IDS_IDENTITY                    103
#define IDS_ISSUED                      104
#define IDS_EXPIRES                     105
#define IDS_TIMELEFT                    106
#define IDS_LOCATION                    107
#define IDS_PARENT                      108
#define IDS_TYPE                        109
#define IDS_IVL_EXPIRED                 110
#define IDS_IVL_D_H                     111
#define IDS_IVL_H_M                     112
#define IDS_IVL_M_S                     113
#define IDS_IVL_S                       114
#define IDS_IVL_UNKNOWN                 115
#define IDS_LIFETIME                    116
#define IDS_IVL_1D                      117
#define IDS_IVL_1H                      118
#define IDS_IVL_1M                      119
#define IDS_IVL_1S                      120
#define IDS_IVL_D                       121
#define IDS_IVL_H                       122
#define IDS_IVL_M                       123
#define IDS_IVL_S_SPEC                  124
#define IDS_IVL_M_SPEC                  125
#define IDS_IVL_H_SPEC                  126
#define IDS_IVL_D_SPEC                  127
#define IDS_IVl_W_SPEC                  128
#define IDS_IVL_W_SPEC                  128
#define IDS_FLAGS                       129
#define IDS_RENEW_TIMELEFT              130
#define IDS_RENEW_EXPIRES               131
#define IDS_RENEW_LIFETIME              132

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
