//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by C:\work\pismere\athena\auth\krb5\src\windows\identity\plugins\krb4\lang\en_us\langres.rc
//
#define IDD_NC_KRB4                     103
#define IDS_PLUGIN_DESC                 103
#define IDD_CFG_KRB4                    104
#define IDS_NC_K4_SHORT                 104
#define IDS_ERR_REALM                   105
#define IDD_CFG_IDS_KRB4                105
#define IDS_ERR_PRINCIPAL               106
#define IDD_CFG_ID_KRB4                 106
#define IDS_ERR_INVINST                 107
#define IDI_PLUGIN                      107
#define IDS_ERR_PWINTKT                 108
#define IDS_CT_DISABLED                 109
#define IDS_CT_TGTFOR                   110
#define IDS_METHOD_AUTO                 111
#define IDS_METHOD_PWD                  112
#define IDS_METHOD_K524                 113
#define IDS_CFG_IDS_KRB4_SHORT          114
#define IDS_KRB4_SHORT_DESC             128
#define IDS_KRB4_LONG_DESC              129
#define IDS_CFG_KRB4_LONG               135
#define IDS_CFG_KRB4_SHORT              136
#define IDC_CFG_LBL_CACHE               1025
#define IDC_CFG_LBL_CFGFILE             1026
#define IDC_CFG_LBL_RLMPATH             1027
#define IDC_CFG_CACHE                   1028
#define IDC_CFG_CFGPATH                 1029
#define IDC_CFG_RLMPATH                 1030
#define IDC_CFG_CFGBROW                 1031
#define IDC_CFG_RLMBROW                 1032
#define IDC_NCK4_OBTAIN                 1033
#define IDC_NCK4_AUTO                   1034
#define IDC_NCK4_K524                   1035
#define IDC_NCK4_PWD                    1036
#define IDC_CFG_GETTIX                  1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
